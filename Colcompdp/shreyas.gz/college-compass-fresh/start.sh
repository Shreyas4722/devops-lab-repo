#!/bin/bash

echo "🧭 College Compass - Quick Start Script"
echo "========================================"
echo ""

# Check if node is installed
if ! command -v node &> /dev/null
then
    echo "❌ Node.js is not installed. Please install Node.js first."
    echo "Download from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Check if npm is installed
if ! command -v npm &> /dev/null
then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ npm version: $(npm --version)"
echo ""

# Function to check if MongoDB is running
check_mongodb() {
    if command -v mongod &> /dev/null
    then
        if pgrep -x "mongod" > /dev/null
        then
            echo "✅ MongoDB is running"
            return 0
        else
            echo "⚠️  MongoDB is not running"
            echo "Starting MongoDB..."
            mongod --fork --logpath /tmp/mongodb.log --dbpath /tmp/mongodb-data
            sleep 2
            if pgrep -x "mongod" > /dev/null
            then
                echo "✅ MongoDB started successfully"
                return 0
            else
                echo "❌ Failed to start MongoDB"
                return 1
            fi
        fi
    else
        echo "⚠️  MongoDB not found locally"
        echo "Please either:"
        echo "  1. Install MongoDB: https://www.mongodb.com/try/download/community"
        echo "  2. Use MongoDB Atlas: https://www.mongodb.com/cloud/atlas"
        echo "     Then update server/.env with your Atlas connection string"
        return 1
    fi
}

# Check MongoDB
echo "Checking MongoDB..."
check_mongodb
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
echo ""

# Install client dependencies
if [ ! -d "client/node_modules" ]; then
    echo "Installing frontend dependencies..."
    cd client
    npm install
    cd ..
    echo "✅ Frontend dependencies installed"
else
    echo "✅ Frontend dependencies already installed"
fi

echo ""

# Install server dependencies
if [ ! -d "server/node_modules" ]; then
    echo "Installing backend dependencies..."
    cd server
    npm install
    cd ..
    echo "✅ Backend dependencies installed"
else
    echo "✅ Backend dependencies already installed"
fi

echo ""

# Setup .env file
if [ ! -f "server/.env" ]; then
    echo "Setting up environment variables..."
    cp server/.env.example server/.env
    echo "✅ .env file created (please update with your MongoDB URI if needed)"
else
    echo "✅ .env file already exists"
fi

echo ""

# Ask to seed database
read -p "Do you want to seed the database with sample data? (y/n): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]
then
    echo "🌱 Seeding database..."
    cd server
    node seed.js
    cd ..
fi

echo ""
echo "🚀 Starting College Compass..."
echo ""
echo "Backend will run on: http://localhost:5000"
echo "Frontend will run on: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop both servers"
echo ""

# Start backend in background
cd server
npm run dev > ../server.log 2>&1 &
SERVER_PID=$!
cd ..

# Wait a bit for server to start
sleep 3

# Start frontend in background
cd client
npm run dev > ../client.log 2>&1 &
CLIENT_PID=$!
cd ..

echo "✅ Both servers started!"
echo "Backend PID: $SERVER_PID"
echo "Frontend PID: $CLIENT_PID"
echo ""
echo "Logs:"
echo "  Backend: tail -f server.log"
echo "  Frontend: tail -f client.log"
echo ""
echo "To stop servers manually:"
echo "  kill $SERVER_PID $CLIENT_PID"
echo ""

# Wait for user to stop
wait
