import mongoose from 'mongoose'
import dotenv from 'dotenv'
import Location from './models/Location.js'
import Faculty from './models/Faculty.js'

dotenv.config()

// Sample data for locations
const sampleLocations = [
  {
    name: 'Computer Science Lab 1',
    type: 'Lab',
    building: 'Engineering Block A',
    floor: 'Ground Floor',
    description: 'Advanced computer lab with 50 workstations, equipped with latest software and hardware for programming and development.',
    capacity: 50,
    amenities: ['Projector', 'Air Conditioning', 'High-speed Internet']
  },
  {
    name: 'Main Library',
    type: 'Library',
    building: 'Central Block',
    floor: 'First Floor',
    description: 'Central library with extensive collection of books, journals, and digital resources. Quiet study areas available.',
    capacity: 200,
    amenities: ['Reading Room', 'Digital Library', 'Study Cubicles', 'Printing Services']
  },
  {
    name: 'Lecture Hall 101',
    type: 'Classroom',
    building: 'Academic Block B',
    floor: 'First Floor',
    description: 'Large lecture hall suitable for mass lectures and seminars.',
    capacity: 100,
    amenities: ['Smart Board', 'Projector', 'Audio System', 'Air Conditioning']
  },
  {
    name: 'Student Cafeteria',
    type: 'Cafeteria',
    building: 'Student Center',
    floor: 'Ground Floor',
    description: 'Main cafeteria offering variety of food options including Indian, Chinese, and continental cuisines.',
    capacity: 300,
    amenities: ['WiFi', 'Outdoor Seating', 'Multiple Counters']
  },
  {
    name: 'Dean\'s Office',
    type: 'Office',
    building: 'Administration Block',
    floor: 'Second Floor',
    description: 'Office of the Dean of Engineering. Student consultation hours: Mon-Fri, 2PM-4PM',
    amenities: ['Waiting Area', 'Reception']
  },
  {
    name: 'Main Auditorium',
    type: 'Auditorium',
    building: 'Central Block',
    floor: 'Ground Floor',
    description: 'Large auditorium for events, cultural programs, and guest lectures.',
    capacity: 500,
    amenities: ['Stage', 'Professional Sound System', 'Lighting', 'Green Room']
  },
  {
    name: 'Physics Lab',
    type: 'Lab',
    building: 'Science Block',
    floor: 'Second Floor',
    description: 'Well-equipped physics laboratory for conducting experiments.',
    capacity: 40,
    amenities: ['Lab Equipment', 'Safety Equipment', 'Digital Instruments']
  },
  {
    name: 'Basketball Court',
    type: 'Sports',
    building: 'Sports Complex',
    floor: 'Ground Floor',
    description: 'Indoor basketball court available for students.',
    amenities: ['Seating Gallery', 'Locker Rooms', 'First Aid']
  },
  {
    name: 'Seminar Hall 203',
    type: 'Classroom',
    building: 'Academic Block C',
    floor: 'Second Floor',
    description: 'Medium-sized seminar hall for interactive sessions and workshops.',
    capacity: 60,
    amenities: ['Projector', 'Whiteboard', 'WiFi', 'Air Conditioning']
  },
  {
    name: 'Career Services Office',
    type: 'Office',
    building: 'Administration Block',
    floor: 'First Floor',
    description: 'Career guidance and placement assistance office.',
    amenities: ['Counseling Rooms', 'Resource Library']
  }
]

// Sample data for faculty
const sampleFaculty = [
  {
    name: 'Dr. Rajesh Kumar',
    designation: 'Professor',
    department: 'Computer Science',
    office: 'Engineering Block A, Room 305',
    email: 'rajesh.kumar@alliance.edu.in',
    phone: '+91-9876543210',
    specialization: ['Artificial Intelligence', 'Machine Learning', 'Data Science'],
    officeHours: 'Mon-Fri: 2PM-4PM'
  },
  {
    name: 'Dr. Priya Sharma',
    designation: 'Associate Professor',
    department: 'Computer Science',
    office: 'Engineering Block A, Room 307',
    email: 'priya.sharma@alliance.edu.in',
    phone: '+91-9876543211',
    specialization: ['Database Systems', 'Cloud Computing'],
    officeHours: 'Tue-Thu: 3PM-5PM'
  },
  {
    name: 'Prof. Anil Verma',
    designation: 'Assistant Professor',
    department: 'Electronics',
    office: 'Engineering Block B, Room 201',
    email: 'anil.verma@alliance.edu.in',
    phone: '+91-9876543212',
    specialization: ['VLSI Design', 'Digital Electronics'],
    officeHours: 'Mon-Wed: 10AM-12PM'
  },
  {
    name: 'Dr. Meera Reddy',
    designation: 'Professor',
    department: 'Physics',
    office: 'Science Block, Room 401',
    email: 'meera.reddy@alliance.edu.in',
    phone: '+91-9876543213',
    specialization: ['Quantum Physics', 'Thermodynamics'],
    officeHours: 'Wed-Fri: 11AM-1PM'
  },
  {
    name: 'Prof. Suresh Patel',
    designation: 'Assistant Professor',
    department: 'Mathematics',
    office: 'Academic Block C, Room 102',
    email: 'suresh.patel@alliance.edu.in',
    phone: '+91-9876543214',
    specialization: ['Applied Mathematics', 'Statistics'],
    officeHours: 'Mon-Fri: 9AM-10AM'
  },
  {
    name: 'Dr. Kavita Singh',
    designation: 'Associate Professor',
    department: 'Computer Science',
    office: 'Engineering Block A, Room 309',
    email: 'kavita.singh@alliance.edu.in',
    phone: '+91-9876543215',
    specialization: ['Software Engineering', 'Agile Methodologies'],
    officeHours: 'Tue-Thu: 2PM-4PM'
  },
  {
    name: 'Prof. Ramesh Rao',
    designation: 'Assistant Professor',
    department: 'Mechanical Engineering',
    office: 'Engineering Block C, Room 205',
    email: 'ramesh.rao@alliance.edu.in',
    phone: '+91-9876543216',
    specialization: ['Thermodynamics', 'Fluid Mechanics'],
    officeHours: 'Mon-Wed: 3PM-5PM'
  },
  {
    name: 'Dr. Anita Desai',
    designation: 'Professor',
    department: 'Chemistry',
    office: 'Science Block, Room 303',
    email: 'anita.desai@alliance.edu.in',
    phone: '+91-9876543217',
    specialization: ['Organic Chemistry', 'Analytical Chemistry'],
    officeHours: 'Wed-Fri: 10AM-12PM'
  }
]

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/college_compass', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    console.log('✅ Connected to MongoDB')

    // Clear existing data
    await Location.deleteMany({})
    await Faculty.deleteMany({})
    console.log('🗑️  Cleared existing data')

    // Insert sample data
    await Location.insertMany(sampleLocations)
    await Faculty.insertMany(sampleFaculty)
    console.log('✅ Sample data inserted successfully')

    console.log(`📍 ${sampleLocations.length} locations added`)
    console.log(`👨‍🏫 ${sampleFaculty.length} faculty members added`)

    process.exit(0)
  } catch (error) {
    console.error('❌ Error seeding database:', error)
    process.exit(1)
  }
}

seedDatabase()
