# College Compass - Deployment Guide

## Quick Deployment Checklist

### ✅ Pre-Deployment
- [ ] All code tested locally
- [ ] Database seeded with data
- [ ] Environment variables configured
- [ ] Git repository created and pushed
- [ ] MongoDB Atlas cluster created (for production)

### ✅ Frontend Deployment (Vercel)
- [ ] Vercel account created
- [ ] Repository connected
- [ ] Build settings configured
- [ ] Environment variables added
- [ ] Custom domain configured (optional)

### ✅ Backend Deployment (Render/Railway)
- [ ] Hosting account created
- [ ] Repository connected
- [ ] Start command configured
- [ ] MongoDB Atlas URI added
- [ ] CORS settings updated

---

## Detailed Deployment Steps

## 1. MongoDB Atlas Setup (Database)

### Step 1: Create Account & Cluster
1. Go to https://www.mongodb.com/cloud/atlas
2. Sign up for free account
3. Create a new cluster (choose free tier M0)
4. Wait for cluster creation (2-3 minutes)

### Step 2: Configure Database Access
1. Go to "Database Access" in left menu
2. Click "Add New Database User"
3. Choose "Password" authentication
4. Create username and strong password
5. Set user privileges to "Read and write to any database"
6. Click "Add User"

### Step 3: Configure Network Access
1. Go to "Network Access" in left menu
2. Click "Add IP Address"
3. Choose "Allow Access from Anywhere" (0.0.0.0/0)
   - For production, restrict to specific IPs
4. Click "Confirm"

### Step 4: Get Connection String
1. Go to "Databases" in left menu
2. Click "Connect" on your cluster
3. Choose "Connect your application"
4. Copy the connection string
5. Replace `<password>` with your database user password
6. Replace `myFirstDatabase` with `college_compass`

Example:
```
mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/college_compass?retryWrites=true&w=majority
```

---

## 2. Backend Deployment (Render)

### Step 1: Prepare Repository
```bash
cd college-compass
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-url>
git push -u origin main
```

### Step 2: Deploy on Render
1. Go to https://render.com and sign up
2. Click "New +" → "Web Service"
3. Connect your GitHub repository
4. Configure:
   - **Name**: college-compass-api
   - **Root Directory**: server
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free

### Step 3: Add Environment Variables
In Render dashboard:
1. Go to "Environment" tab
2. Add these variables:
   ```
   MONGODB_URI=<your-mongodb-atlas-connection-string>
   NODE_ENV=production
   PORT=5000
   ```

### Step 4: Deploy
1. Click "Create Web Service"
2. Wait for deployment (3-5 minutes)
3. Copy your backend URL (e.g., https://college-compass-api.onrender.com)

### Step 5: Seed Database
Option A - Using Render Shell:
1. Go to your service on Render
2. Click "Shell" tab
3. Run: `node seed.js`

Option B - Locally with production database:
```bash
cd server
# Temporarily update .env with production MongoDB URI
node seed.js
```

---

## 3. Frontend Deployment (Vercel)

### Step 1: Install Vercel CLI
```bash
npm install -g vercel
```

### Step 2: Build Frontend
```bash
cd client
npm run build
```

### Step 3: Deploy to Vercel
```bash
vercel
```

Follow the prompts:
- Set up and deploy: Y
- Which scope: Your account
- Link to existing project: N
- Project name: college-compass
- In which directory is your code located: ./
- Want to override settings: Y
- Build Command: `npm run build`
- Output Directory: `dist`
- Development Command: `npm run dev`

### Step 4: Configure Environment Variables
1. Go to Vercel dashboard
2. Select your project
3. Go to Settings → Environment Variables
4. Add:
   ```
   VITE_API_URL=<your-render-backend-url>
   ```
   Example: `https://college-compass-api.onrender.com`

### Step 5: Redeploy
```bash
vercel --prod
```

---

## 4. Update Backend CORS

After deploying frontend, update your backend to allow requests from your frontend domain.

In `server/server.js`, update CORS configuration:
```javascript
app.use(cors({
  origin: [
    'http://localhost:3000',
    'https://college-compass.vercel.app', // Your Vercel domain
    'https://your-custom-domain.com'      // If you have one
  ]
}))
```

Commit and push changes - Render will auto-deploy.

---

## 5. Custom Domain (Optional)

### For Frontend (Vercel)
1. Go to project Settings → Domains
2. Add your domain
3. Follow Vercel's DNS configuration instructions

### For Backend (Render)
1. Go to service Settings → Custom Domains
2. Add your domain
3. Follow Render's DNS configuration instructions

---

## Alternative: Deploy Both on Railway

Railway can host both frontend and backend in one place.

### Step 1: Create Railway Account
1. Go to https://railway.app
2. Sign up with GitHub

### Step 2: Deploy Backend
1. Click "New Project"
2. Choose "Deploy from GitHub repo"
3. Select your repository
4. Railway auto-detects Node.js
5. Add environment variables:
   - `MONGODB_URI`
   - `NODE_ENV=production`
6. Set root directory to `server`
7. Deploy

### Step 3: Deploy Frontend
1. Click "New" → "Service"
2. Choose same repository
3. Set root directory to `client`
4. Add build command: `npm run build`
5. Add start command: `npm run preview`
6. Add environment variable:
   - `VITE_API_URL=<backend-railway-url>`
7. Deploy

---

## Testing Your Deployment

### Backend Health Check
```bash
curl https://your-backend-url.com/api/health
```

Expected response:
```json
{
  "status": "ok",
  "message": "College Compass API is running"
}
```

### Frontend
Visit your Vercel URL and test:
- [ ] Home page loads correctly
- [ ] Search page displays locations
- [ ] Faculty page displays faculty members
- [ ] Navigation works
- [ ] Mobile responsive

---

## Monitoring & Maintenance

### Render
- Check logs in Render dashboard
- Monitor resource usage
- Set up auto-deploy on git push

### Vercel
- Check deployment logs
- Monitor build times
- Set up preview deployments for branches

### MongoDB Atlas
- Monitor database metrics
- Set up alerts
- Regular backups enabled by default

---

## Troubleshooting

### "Cannot connect to database"
- Check MongoDB Atlas network access (IP whitelist)
- Verify connection string in environment variables
- Check database user credentials

### "CORS Error"
- Update CORS settings in backend
- Add frontend domain to allowed origins
- Check protocol (http vs https)

### "Build Failed"
- Check build logs
- Verify all dependencies in package.json
- Test build locally first: `npm run build`

### "API requests failing"
- Verify API_URL in frontend environment variables
- Check backend is running
- Test endpoints with curl/Postman

---

## Cost Optimization

### Free Tier Limits
**Render Free Tier:**
- Service spins down after 15 minutes of inactivity
- First request after spin-down takes 30-60 seconds
- 750 hours/month free

**Vercel Free Tier:**
- 100 GB bandwidth/month
- Unlimited projects
- Automatic HTTPS

**MongoDB Atlas Free Tier:**
- 512 MB storage
- Shared RAM
- Perfect for development/small apps

### Upgrade When Needed
Consider upgrading if you experience:
- Frequent cold starts affecting UX
- Running out of storage
- High traffic exceeding free tier limits

---

## Security Best Practices

1. **Never commit .env files**
   - Use .gitignore
   - Store secrets in hosting platform

2. **Use environment variables**
   - Different values for dev/prod
   - Never hardcode credentials

3. **Enable HTTPS**
   - Both Vercel and Render provide automatic HTTPS
   - Force HTTPS redirects

4. **Restrict MongoDB access**
   - In production, limit IP addresses
   - Use strong passwords
   - Regular security audits

5. **Rate limiting**
   - Implement rate limiting in production
   - Protect against DDoS attacks

---

## Need Help?

- **Render Docs**: https://render.com/docs
- **Vercel Docs**: https://vercel.com/docs
- **MongoDB Atlas Docs**: https://docs.atlas.mongodb.com/
- **Railway Docs**: https://docs.railway.app/

---

**Deployment completed! 🎉**

Your College Compass application is now live and accessible worldwide!
